var log = function (arg) {
    console.log.apply(console, arguments);
};