<?php
class SendusController extends AppController{
	
	
	public function index(){
		
	$this->layout = 'madetheme';	
	}
	public function topic() {
		$this->layout = 'madetheme';	
	}

	public function suggestions() {
	$this->layout = 'madetheme';	
	}
	

}
?>