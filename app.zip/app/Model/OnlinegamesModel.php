<?php
App::uses('AppModel', 'AppModel');

class OnlinegamesModel extends AppModel {
	
	

}
